#!/bin/bash

# ==============================================================================
# Script Name: reproduce_benchmarks2.sh
# Description: Reproduce aligned-parameter comparison.
#              TF-QuanONet at matched parameter count vs DeepONet & FNO.
#              Fixed Scale(0.001) & TF(true) for QuanONet.
# Usage:       ./scripts/reproduce_benchmarks2.sh [GPU_ID]
# ==============================================================================

# 1. Configuration
# ----------------
GPU_ID=$1
PREFIX="benchmarks2_reproduction"

# Hyperparameters
NUM_TRAIN=100        # Reduced training functions
TRAIN_SAMPLE=100     # Increased samples per function
NUM_TEST=1000
TEST_SAMPLE=100
BATCH_SIZE=100
LR=0.0001

# Iteration Lists
SEEDS=(0 1 2 3 4)
OPERATORS=("Antideriv" "Homogeneous" "Nonlinear")
MODELS=("QuanONet" "DeepONet" "FNO") # QuanONet here implies TF-QuanONet

# ==============================================================================
# 2. Setup Device Flag
# ==============================================================================
if [ -n "$GPU_ID" ]; then
    GPU_FLAG="--gpu ${GPU_ID}"
    echo "🔧 Specified running device: GPU ${GPU_ID}"
else
    GPU_FLAG=""
    echo "🤖 For unspecified devices: Using smart default (Quantum->CPU, Classical->GPU)"
fi

echo "🚀 Starting Aligned-Parameter Comparison..."
echo "📂 Output Directory: ${PREFIX}"

# ==============================================================================
# 3. Main Loop
# ==============================================================================

for OP in "${OPERATORS[@]}"; do
    
    # Only ODE operators
    PROB_TYPE="ODE"
    EPOCHS=1000
    PTS=100
    PTS_0=100

    echo "----------------------------------------------------------------"
    echo "▶ Operator: ${OP} | Epochs: ${EPOCHS} | Train: ${NUM_TRAIN}x${TRAIN_SAMPLE}"
    echo "----------------------------------------------------------------"

    for MODEL in "${MODELS[@]}"; do
        
        # --- Configure Model Specific Settings ---
        NET_SIZE=""
        EXTRA_ARGS=""
        CURRENT_BATCH_SIZE=${BATCH_SIZE}
        
        if [[ "$MODEL" == "QuanONet" ]]; then
            # TF-QuanONet at aligned parameter count
            # Scale=0.001, Freq=True, Size=160 2 90 2
            NET_SIZE="160 2 90 2"
            SCALE="0.001"
            IF_TF="true"
            EXTRA_ARGS="--scale_coeff ${SCALE} --if_trainable_freq ${IF_TF}"
            MODEL_DESC="TF-QuanONet (Scale=${SCALE})"
            
        elif [[ "$MODEL" == "DeepONet" ]]; then
            # DeepONet Setup
            # Size=4 32 4 32
            NET_SIZE="4 32 4 32"
            MODEL_DESC="DeepONet"
            
        elif [[ "$MODEL" == "FNO" ]]; then
            # FNO Setup
            # Size=19 9 3 43 (modes, width, depth, fc_hidden) → 10005 real params
            NET_SIZE="19 9 3 43"
            MODEL_DESC="FNO"
            CURRENT_BATCH_SIZE=1
        fi

        PIDS=()
        for SEED in "${SEEDS[@]}"; do
            echo "  Launching ${MODEL_DESC} | Size=[${NET_SIZE}] | Seed=${SEED}"
            LOG_FILE="/dev/null"
            mkdir -p "${PREFIX}"

            python main.py \
                --model_type "${MODEL}" \
                --operator "${OP}" \
                --net_size ${NET_SIZE} \
                --num_train ${NUM_TRAIN} --train_sample_num ${TRAIN_SAMPLE} \
                --num_test ${NUM_TEST} --test_sample_num ${TEST_SAMPLE} \
                --batch_size ${CURRENT_BATCH_SIZE} \
                --num_epochs ${EPOCHS} \
                --learning_rate ${LR} \
                --num_points ${PTS} --num_points_0 ${PTS_0} \
                --seed "${SEED}" \
                --prefix "${PREFIX}" \
                ${GPU_FLAG} \
                ${EXTRA_ARGS} \
                > "${LOG_FILE}" 2>&1 &
            PIDS+=($!)
        done

        # Wait for all seeds to finish, check exit codes
        FAILED=0
        for PID in "${PIDS[@]}"; do
            wait "$PID" || FAILED=$((FAILED + 1))
        done
        if [ $FAILED -gt 0 ]; then
            echo "  ❌ ${FAILED} seed(s) failed for ${MODEL_DESC} / ${OP}, check logs in ${PREFIX}/"
            exit 1
        fi
        echo "  ✅ All seeds done for ${MODEL_DESC} / ${OP}"
    done
done

echo "✅ Aligned-parameter comparison experiments completed."