"""
Unified Data Manager for Operator Learning.
Handles data loading, generation, caching, and model-specific formatting (e.g., FNO).
"""

import os
import numpy as np
import logging
from .data_generation import (
    generate_identity_operator_data,
    generate_antideriv_operator_data,
    generate_homogeneous_operator_data,
    generate_nonlinear_operator_data,
    generate_rdiffusion_operator_data,
    generate_advection_operator_data,
    generate_darcy_operator_data,
    generate_ode_operator_data,
    generate_pde_operator_data
)
from .data_processing import ode_encode, pde_encode, ode_fncode, pde_fncode

# Map operator names to their generator functions
GENERATOR_MAP = {
    'Identity': generate_identity_operator_data,
    'Antideriv': generate_antideriv_operator_data,
    'Homogeneous': generate_homogeneous_operator_data,
    'Nonlinear': generate_nonlinear_operator_data,
    'RDiffusion': generate_rdiffusion_operator_data,
    'Advection': generate_advection_operator_data,
    'Darcy': generate_darcy_operator_data,
    # Generic fallbacks
    'ODE': generate_ode_operator_data,
    'PDE': generate_pde_operator_data
}

class DataManager:
    def __init__(self, config, data_dir="data", logger=None, input_sampler=None):
        """
        Args:
            config (dict): Configuration dictionary containing:
                - operator_type, model_type, num_train, num_test
                - num_points, num_points_0, train_sample_num, test_sample_num
                - num_cal (optional)
            data_dir (str): Root directory for data storage.
            logger: Optional logger instance.
            input_sampler: optional callable ``f(num_cal) -> (u0_fn, u0_cal)``
                that replaces the default GRF sampler.  When provided, disk
                caching is bypassed (both at the raw-data level inside the
                generator and at the processed-data level inside DataManager).
        """
        self.config = config
        self.data_dir = data_dir
        self.logger = logger or logging.getLogger(__name__)
        self.input_sampler = input_sampler

        self.operator_type = config['operator']
        self.model_type = config.get('model_type', 'DeepONet')
        
        # Ensure critical parameters exist with defaults
        self.num_points = config.get('num_points', 100)
        self.num_points_0 = config.get('num_points_0', 100)
        if config.get('num_cal') is not None:
            self.num_cal = config['num_cal']
            
        # 2. set the default value according to the operator type
        else:
            if self.operator_type in ['RDiffusion', 'Advection', 'Darcy']:
                self.num_cal = 100   # PDE default
                self.logger.info(f"Using default num_cal=100 for PDE operator: {self.operator_type}")
            else:
                self.num_cal = 1000  # ODE default (Antideriv, Homogeneous, etc.)
                self.logger.info(f"Using default num_cal=1000 for ODE operator: {self.operator_type}")
        
    def get_data(self):
        """
        Main entry point.
        Returns a dictionary containing:
            - train_input, train_output
            - test_input, test_output
            - (Optional) Branch/Trunk splits if applicable
        """
        # 1. Determine filenames based on config
        filename = self._get_filename()
        filepath = os.path.join(self.data_dir, self.operator_type, filename)

        # 2. Try loading cached data — skipped when a custom input_sampler is set
        if self.input_sampler is None and os.path.exists(filepath):
            self.logger.info(f"Loading cached data from {filepath}")
            try:
                data = np.load(filepath)
                # Convert to dict
                return {k: data[k] for k in data.files}
            except Exception as e:
                self.logger.warning(f"Failed to load cached data: {e}. Regenerating...")

        # 3. Generate new data
        self.logger.info(f"Generating new data for {self.operator_type}...")
        data_dict = self._generate_and_process()

        # 4. Save to cache — skipped when a custom input_sampler is set
        if self.input_sampler is None:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            self.logger.info(f"Saving data to {filepath}")
            np.savez_compressed(filepath, **data_dict)
        
        return data_dict

    def _get_filename(self):
        """Generate unique filename based on data parameters."""
        c = self.config
        # Base name: Operator_Train_Test_OutRes_InRes
        base = f"{self.operator_type}_{c['num_train']}_{c['num_test']}_{self.num_points}_{self.num_points_0}"
        
        # If model is FNO, the data format is fundamentally different (Grid vs Coordinate)
        if self.model_type == 'FNO':
            base += "_FNO"
        else:
            # For DeepONet/FNN, sample_nums matter
            base += f"_{c.get('train_sample_num', 10)}_{c.get('test_sample_num', 100)}"
            
        return f"{base}.npz"

    def _generate_and_process(self):
        """
        Orchestrates generation -> encoding -> formatting.
        """
        # A. Select Generator
        generator = GENERATOR_MAP.get(self.operator_type)
        if not generator:
            raise ValueError(f"Unknown operator type: {self.operator_type}")
            
        # Helper to call generator with standardized args
        # Note: We bind the static args here so the Encoders just call gen_func(nt, nte)
        def gen_func_wrapper(nt, nte, *args, **kwargs):
                    return generator(
                        nt, nte,
                        self.num_points,
                        self.num_points_0,
                        num_cal=self.num_cal,
                        input_sampler=self.input_sampler,
                    )

        # B. Encode Data based on Model Type
        c = self.config
        
        if self.model_type == 'FNO':
            # === FNO Specific Path ===
            # FNO requires grid-structured data. We use fncode from data_processing.py
            
            # FNO enforces sample_num == num_points usually

            is_pde = self.operator_type in ['RDiffusion', 'Advection', 'Darcy']
            encoder = pde_fncode if is_pde else ode_fncode
            train_in, _, train_out, test_in, _, test_out = encoder(
                gen_func_wrapper, 
                c['num_train'], c['num_test'], 
                self.num_points
            )
            
            return {
                'train_input': train_in,
                'train_output': train_out,
                'test_input': test_in,
                'test_output': test_out
            }
            
        else:
            # === DeepONet / FNN / QuanONet Path ===
            # Use ode_encode or pde_encode based on operator category
            is_pde = self.operator_type in ['RDiffusion', 'Advection', 'Darcy']
            encoder = pde_encode if is_pde else ode_encode
            
            train_branch, train_trunk, train_out, test_branch, test_trunk, test_out = encoder(
                gen_func_wrapper,
                c['num_train'], c['num_test'],
                self.num_points, self.num_points_0,
                c.get('train_sample_num', 10),
                c.get('test_sample_num', 100),
                self.num_cal
            )
            
            # Combine for saving (Standard format)
            return {
                'train_branch_input': train_branch,
                'train_trunk_input': train_trunk,
                'train_output': train_out,
                'test_branch_input': test_branch,
                'test_trunk_input': test_trunk,
                'test_output': test_out,
                # Also save combined input for FNN and HEAQNN convenience
                'train_input': np.concatenate([train_branch, train_trunk], axis=1),
                'test_input': np.concatenate([test_branch, test_trunk], axis=1)
            }