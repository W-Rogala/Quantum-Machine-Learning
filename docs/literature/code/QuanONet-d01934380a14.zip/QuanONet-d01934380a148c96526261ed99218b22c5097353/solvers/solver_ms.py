"""
MindSpore Solver for Quantum/Classical Models (QuanONet, HEAQNN).
Refactored from original train.py.
"""
import os
import sys
import gc
import numpy as np
import json
from datetime import datetime
from tqdm import tqdm

try:
    import mindspore as ms
    import mindspore.nn as nn
    import mindspore.numpy as mnp
    from mindspore.train.serialization import save_checkpoint, load_checkpoint, load_param_into_net
except ImportError:
    ms = None

from data_utils.data_manager import DataManager
from utils.logger import ExperimentLogger, setup_logger, StreamToLogger
from utils.metrics import compute_metrics
from utils.utils import count_parameters 

from core.models_ms import QuanONetMS, HEAQNNMS, FNNMS, DeepONetMS
from core.quantum_circuits_ms import generate_simple_hamiltonian, ham_diag_to_operator

class MSSolver:
    def __init__(self, config, input_sampler=None):
        if ms is None:
            raise ImportError("MindSpore is required for MSSolver but not found.")
            
        self.config = config
        self.operator_type = config['operator']
        self.model_type = config['model_type']
        
        prefix = config.get('prefix') or "outputs"
        self.exp_logger = ExperimentLogger(config, base_output_dir=prefix)
        self.run_id = self.exp_logger.exp_name
        self.config['run_id'] = self.run_id 

        # 1. Setup Logger
        self.logger = setup_logger(self.exp_logger.text_log_path)
        sys.stdout = StreamToLogger(self.logger) 
        
        # Context Setup
        device_target = "GPU" if config.get('gpu') is not None else "CPU"
        mode = ms.PYNATIVE_MODE  # MQOps only supports PyNative; use segmented training to manage memory
        gpu_val = config.get('gpu')
        if gpu_val is not None:
             ms.context.set_context(device_id=int(gpu_val))
        ms.context.set_context(mode=mode, device_target=device_target)

        self.logger.info(f"Initialized MSSolver (Quantum) for {self.model_type}")
        self.logger.info(f"Context: {device_target}, Mode: PyNative")

        # 2. Load Data (Unified Manager)
        self.input_sampler = input_sampler
        self.dm = DataManager(config, data_dir=os.path.join(prefix, "..", "data"), logger=self.logger, input_sampler=input_sampler)
        self.data_dict_np = self.dm.get_data() 
        self._convert_data_to_ms() 
        
        # 3. Build Model
        self.model = self._create_model()
        
        # Optimization Setup (optimizer built lazily in train())
        self.loss_fn = nn.MSELoss()
        
        self.best_loss = float('inf')

    def _convert_data_to_ms(self):
        """Converts numpy data from DataManager to MindSpore Tensors."""
        self.logger.info("Routing data for MindSpore models...")
        self.data = self.data_dict_np

        if self.model_type in ['HEAQNN', 'FNN']:
            self.train_input = self.data['train_input']
            self.test_input  = self.data['test_input']
        elif self.model_type == 'FNO':
            # DataManager provides 'train_input' as (N, n_pts, in_ch) for FNO,
            # matching the same format used by DDESolver.
            self.train_input = self.data['train_input'].astype(np.float32)
            self.test_input  = self.data['test_input'].astype(np.float32)
        else:
            self.train_input = (self.data['train_branch_input'], self.data['train_trunk_input'])
            self.test_input  = (self.data['test_branch_input'], self.data['test_trunk_input'])
        self.train_output = self.data['train_output']
        self.test_output  = self.data['test_output']

    def _create_model(self):
        self.logger.info("Creating Quantum Model...")
        ham_bound = self.config.get('ham_bound')
        if ham_bound is None: ham_bound = [-5, 5]
        
        if self.config.get('ham_diag') is None:
            ham = generate_simple_hamiltonian(
                self.config['num_qubits'], 
                lower_bound=ham_bound[0], 
                upper_bound=ham_bound[1], 
                pauli=self.config.get('ham_pauli', 'Z')
            )
        else:
            ham = ham_diag_to_operator(self.config['ham_diag'], self.config['num_qubits'])
            
        if hasattr(ham, 'hamiltonian'):
            self.logger.info(f"Hamiltonian Formula:\n{ham.hamiltonian}")
        else:
            self.logger.info(f"Hamiltonian:\n{ham}")

        net_size = tuple(self.config.get('net_size', [20, 2, 10, 2]))
        if_trainable_freq = str(self.config.get('if_trainable_freq', 'true')).lower() == 'true'

        if self.model_type == 'QuanONet':
            branch_in = self.data['train_branch_input'].shape[1]
            trunk_in = self.data['train_trunk_input'].shape[1]
            model = QuanONetMS(self.config['num_qubits'], branch_in, trunk_in, net_size, ham,
                             self.config.get('scale_coeff', 0.01), if_trainable_freq)
        elif self.model_type == 'HEAQNN':
            input_size = self.data['train_input'].shape[1]
            model = HEAQNNMS(self.config['num_qubits'], input_size, net_size, ham,
                           self.config.get('scale_coeff', 0.01), if_trainable_freq)
        elif self.model_type == 'DeepONet': 
            branch_in = self.data['train_branch_input'].shape[1]
            trunk_in = self.data['train_trunk_input'].shape[1]
            model = DeepONetMS(branch_in, trunk_in, net_size)
        elif self.model_type == 'FNN':
            input_size = self.data['train_input'].shape[1]
            model = FNNMS(input_size, 1, net_size)
        elif self.model_type == 'FNO':
            from core.models_ms import FNOMS
            # net_size for FNO is interpreted as [modes, width, depth, fc_hidden]
            cfg = list(self.config.get('net_size', []))
            modes     = int(cfg[0]) if len(cfg) > 0 else 15
            width     = int(cfg[1]) if len(cfg) > 1 else 14
            depth     = int(cfg[2]) if len(cfg) > 2 else 3
            fc_hidden = int(cfg[3]) if len(cfg) > 3 else 32
            in_ch = self.train_input.shape[-1]  # 2 (position + function value)
            self.logger.info(f"FNOMS Config: modes={modes}, width={width}, "
                             f"depth={depth}, fc_hidden={fc_hidden}, in_channels={in_ch}")
            model = FNOMS(modes=modes, width=width, layers=depth,
                           fc_hidden=fc_hidden, in_channels=in_ch)
        else:
            raise ValueError(f"Unknown MS model: {self.model_type}")
            
        self.logger.info(f"Model Parameters: {count_parameters(model)}")
        return model


    def _build_optimizer(self, params, total_steps):
        opt_name = self.config.get('optimizer', 'adam').lower()
        lr       = self.config['learning_rate']
        opt_kw   = self.config.get('optimizer_kwargs', {})

        sched     = self.config.get('lr_scheduler', 'none').lower()
        sched_kw  = self.config.get('lr_scheduler_kwargs', {})
        if sched == 'cosine':
            eta_min = sched_kw.get('eta_min', 0.0)
            t = np.arange(total_steps)
            lr_seq = (eta_min + 0.5 * (lr - eta_min) *
                      (1 + np.cos(np.pi * t / total_steps))).tolist()
        elif sched == 'exponential':
            gamma  = sched_kw.get('gamma', 0.99)
            lr_seq = [lr * gamma ** t for t in range(total_steps)]
        elif sched == 'step':
            step_size = sched_kw.get('step_size', 100)
            gamma     = sched_kw.get('gamma', 0.5)
            lr_seq = [lr * gamma ** (t // step_size) for t in range(total_steps)]
        else:
            lr_seq = lr

        opt_map = {
            'adam':   nn.Adam,
            'adamw':  nn.AdamWeightDecay,
            'sgd':    nn.SGD,
            'rmsprop': nn.RMSProp,
        }
        opt_cls = opt_map.get(opt_name, nn.Adam)
        self.logger.info(f"Optimizer: {opt_name}, LR scheduler: {sched}")
        return opt_cls(params, learning_rate=lr_seq, **opt_kw)

    def train(self):
        if self.exp_logger.is_completed():
            print(f"⏩ [Resume] The experiment has been completed and the existing result file has been detected. Skip the training directly.")
            sys.exit(0)
            
        self.logger.info("Starting Training...")

        epochs = self.config['num_epochs']
        total_samples = len(self.train_output)

        current_bs = self.config.get('batch_size', 100)
        if total_samples < current_bs:
            self.logger.warning(f"⚠️ Batch size {current_bs} > total samples {total_samples}. Reducing to {total_samples}.")
            self.config['batch_size'] = total_samples

        batch_size = self.config.get('batch_size', 100)

        if isinstance(self.train_input, tuple):
            num_samples = self.train_input[0].shape[0]
        else:
            num_samples = self.train_input.shape[0]

        num_batches = max(1, int(np.ceil(num_samples / batch_size)))
        self.optimizer = self._build_optimizer(self.model.trainable_params(), epochs * num_batches)
        net_with_loss = nn.WithLossCell(self.model, self.loss_fn)
        train_net = nn.TrainOneStepCell(net_with_loss, self.optimizer)
        train_net.set_train()
        history = {'loss_train': [], 'loss_test': []}
        
        if self.config.get('init_checkpoint'):
             load_checkpoint(self.config['init_checkpoint'], self.model)
             self.logger.info(f"Loaded init checkpoint: {self.config['init_checkpoint']}")

        if not str(self.config.get('if_train', 'true')).lower() == 'true':
            self.logger.info("Skipping training (if_train=false)")
            return history

        for epoch in tqdm(range(epochs)):
            epoch_loss = 0
            epoch_sse = 0.0
            epoch_norm_sq = 0.0
            indices = np.random.permutation(num_samples)

            for i in range(num_batches):
                idx = indices[i * batch_size : (i+1) * batch_size]

                if isinstance(self.train_input, tuple):
                    batch_in = (ms.Tensor(self.train_input[0][idx], ms.float32),
                                ms.Tensor(self.train_input[1][idx], ms.float32))
                else:
                    batch_in = ms.Tensor(self.train_input[idx], ms.float32)

                batch_out = ms.Tensor(self.train_output[idx], ms.float32)

                loss = train_net(batch_in, batch_out)
                loss_val = float(loss.asnumpy())
                epoch_loss += loss_val

                n_elements = batch_out.size
                epoch_sse += loss_val * n_elements
                epoch_norm_sq += float(np.sum(batch_out.asnumpy() ** 2))

            avg_loss = epoch_loss / num_batches
            avg_rel_err = np.sqrt(epoch_sse) / (np.sqrt(epoch_norm_sq) + 1e-8)
            history['loss_train'].append(avg_loss)

            gc.collect()

            self.exp_logger.log_metric("Loss/train", avg_loss, epoch)
            self.exp_logger.log_metric("Error/rel_l2", avg_rel_err, epoch)
            
            # Save Best
            if avg_loss < self.best_loss:
                self.best_loss = avg_loss
                if self.config.get('if_save', True):
                    self.best_model_path = self.exp_logger.get_ckpt_path()
                    save_checkpoint(self.model, self.best_model_path)
                    npz_path = self.best_model_path.replace('.ckpt', '.npz')
                    param_dict_np = {}
                    for param in self.model.get_parameters():
                        param_dict_np[param.name] = param.asnumpy()
                    np.savez(npz_path, **param_dict_np)
            
            if epoch % 10 == 0:
                print(f"Epoch {epoch} | MSE: {avg_loss:.6e} | Rel_L2: {avg_rel_err:.4%}")

        if self.config.get('if_save', True):
            final_model_path = self.exp_logger.get_ckpt_path(is_final=True)
            save_checkpoint(self.model, final_model_path)
            
            npz_path = final_model_path.replace('.ckpt', '.npz')
            param_dict_np = {param.name: param.asnumpy() for param in self.model.get_parameters()}
            np.savez(npz_path, **param_dict_np)
            self.logger.info(f"Saved FINAL model to {final_model_path}")
                
        return history

    def evaluate(self, history=None):
        self.logger.info("Evaluating...")
        if hasattr(self, 'best_model_path') and self.best_model_path and os.path.exists(self.best_model_path):
            param_dict = load_checkpoint(self.best_model_path)
            load_param_into_net(self.model, param_dict)
            self.logger.info(f"Loaded best model from {self.best_model_path}")
        elif self.config.get('ckpt_path') and os.path.exists(self.config['ckpt_path']):
            param_dict = load_checkpoint(self.config['ckpt_path'])
            load_param_into_net(self.model, param_dict)
            self.logger.info(f"Loaded evaluation model from {self.config['ckpt_path']}")
            
        self.model.set_train(False)
        
        batch_size = self.config.get('batch_size', 100)
        preds = []
        
        if isinstance(self.test_input, tuple):
            num_samples = self.test_input[0].shape[0]
        else:
            num_samples = self.test_input.shape[0]
            
        num_batches = int(np.ceil(num_samples / batch_size))
        for i in range(num_batches):
            start = i * batch_size
            end = min((i + 1) * batch_size, num_samples)
            
            if isinstance(self.test_input, tuple):
                batch_in = (ms.Tensor(self.test_input[0][start:end], ms.float32), 
                            ms.Tensor(self.test_input[1][start:end], ms.float32))
            else:
                batch_in = ms.Tensor(self.test_input[start:end], ms.float32)
            
            batch_pred = self.model(batch_in)
            preds.append(batch_pred.asnumpy()) 
            
        y_pred_np = np.concatenate(preds, axis=0)
        
        y_true_np = self.test_output 

        l2_diff = np.linalg.norm(y_pred_np - y_true_np)
        l2_true = np.linalg.norm(y_true_np)
        rel_error = l2_diff / (l2_true + 1e-8)
        
        self.logger.info(f"⚡ Test Relative L2 Error: {rel_error:.6f} ({rel_error:.2%})")
        
        metrics = compute_metrics(y_true_np, y_pred_np)
        metrics['rel_l2'] = rel_error 
        self.logger.info(f"Metrics: {metrics}")
        
        self.exp_logger.save_metrics(metrics, history)
        self.exp_logger.close()
        
        return metrics