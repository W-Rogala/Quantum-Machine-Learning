"""
Unified Solver for PyTorch/DeepXDE based models (DeepONet, FNN, FNO).
"""
import os
import sys
import torch
import numpy as np
os.environ.setdefault("DDE_BACKEND", "pytorch")
import deepxde as dde
from deepxde.data import Data
from deepxde.data.sampler import BatchSampler 

from data_utils.data_manager import DataManager
from utils.logger import ExperimentLogger, setup_logger, StreamToLogger
from utils.metrics import compute_metrics
from utils.common import set_random_seed
from utils.utils import count_parameters

class BestModelCheckpoint(dde.callbacks.Callback):
    """Custom DeepXDE callback to save the best model checkpoint based on training loss."""
    def __init__(self, solver):
        super().__init__()
        self.solver = solver
        self.best_loss = float('inf')
        self.best_ckpt_path = self.solver.exp_logger.get_ckpt_path(is_final=False).replace('.ckpt', '.pt')
        self.best_npz_path = self.best_ckpt_path.replace('.pt', '.npz')

    def on_epoch_end(self):
        current_loss = sum(self.model.train_state.loss_train)
        if current_loss < self.best_loss:
            self.best_loss = current_loss
            
            net = self.model.net
            state_dict = net.module.state_dict() if hasattr(net, 'module') else net.state_dict()
            
            torch.save(state_dict, self.best_ckpt_path)
            param_dict_np = {k: v.cpu().numpy() for k, v in state_dict.items()}
            np.savez(self.best_npz_path, **param_dict_np)


# ==========================================
# Helper Class: DeepXDE Dataset Wrapper
# ==========================================
class Double(Data):
    """
    A simple DeepXDE dataset wrapper that passes pre-loaded numpy arrays.
    Supports correct Batch Sampling for both single input (FNN) and tuple input (DeepONet).
    """
    def __init__(self, X_train, y_train, X_test, y_test):
        self.train_x = X_train
        self.train_y = y_train
        self.test_x = X_test
        self.test_y = y_test
        
        # Initialize BatchSampler
        self.train_sampler = BatchSampler(len(self.train_y), shuffle=True)

    def losses(self, targets, outputs, loss_fn, inputs, model, aux=None):
        return loss_fn(targets, outputs)

    def train_next_batch(self, batch_size=None):
        # Use Sampler to return mini-batches
        if batch_size is None:
            return self.train_x, self.train_y
        
        indices = self.train_sampler.get_next(batch_size)
        
        if isinstance(self.train_x, tuple):
            X_batch = (self.train_x[0][indices], self.train_x[1][indices])
        else:
            X_batch = self.train_x[indices]
            
        return X_batch, self.train_y[indices]

    def test(self):
        return self.test_x, self.test_y
    
# ==========================================
# Main Solver Class
# ==========================================
class DDESolver:
    def __init__(self, config, input_sampler=None):
        self.config = config
        self.input_sampler = input_sampler
        self.model_type = config['model_type']
        self.operator_type = config['operator']
        
        # 1. ExperimentLogger
        prefix = config.get('prefix') or "outputs"
        self.exp_logger = ExperimentLogger(config, base_output_dir=prefix)
        self.run_id = self.exp_logger.exp_name
        self.config['run_id'] = self.run_id
        
        # Set the plain text log orientation
        self.logger = setup_logger(self.exp_logger.text_log_path)
        sys.stdout = StreamToLogger(self.logger)
        
        self.logger.info(f"Initialized DDESolver for {self.model_type} on {self.operator_type}")
        self.logger.info(f"Config: {config}")

        # 2. Load Data
        self.dm = DataManager(config, data_dir=os.path.join(prefix, "..", "data"), logger=self.logger, input_sampler=self.input_sampler)
        self.data_dict = self.dm.get_data()
        
        # 3. Build Model
        self.model = self._build_model()
        
    def _build_model(self):
        """Constructs the DeepXDE Model based on model_type."""
        self.logger.info(f"Building {self.model_type} model...")
        
        # --- Prepare Data Inputs based on Model Type ---
        if self.model_type == 'DeepONet':
            X_train = (self.data_dict['train_branch_input'], self.data_dict['train_trunk_input'])
            X_test  = (self.data_dict['test_branch_input'], self.data_dict['test_trunk_input'])
            y_train = self.data_dict['train_output']
            y_test  = self.data_dict['test_output']
            
            # Architecture Dimensions
            net_config = self.config.get('net_size')
            m = X_train[0].shape[1]      # Branch input dim
            dim_x = X_train[1].shape[1]  # Trunk input dim
            b_depth, b_width = 2, 10
            t_depth, t_width = 2, 10
            last_layer_size = None  # p (latent dimension)

            if not net_config:
                pass # Use defaults
                
            elif len(net_config) == 2:
                b_depth = t_depth = net_config[0]
                b_width = t_width = net_config[1]
                last_layer_size = b_width 
                
            elif len(net_config) == 4:
                b_depth, b_width = net_config[0], net_config[1]
                t_depth, t_width = net_config[2], net_config[3]
                if b_width == t_width:
                    last_layer_size = b_width
                else:
                    last_layer_size = min(b_width, t_width)
                    self.logger.warning(f"⚠️ Width mismatch ({b_width} vs {t_width}). Auto-setting output dim p={last_layer_size}.")

            elif len(net_config) == 5:
                b_depth, b_width = net_config[0], net_config[1]
                t_depth, t_width = net_config[2], net_config[3]
                last_layer_size = net_config[4]
            else:
                self.logger.warning(f"Net size {net_config} not recognized. Using default [2, 32].")

            
            # Branch Net Construction
            if last_layer_size is not None and (len(net_config) == 5 or b_width != t_width):
                layer_size_branch = [m] + [b_width] * (b_depth - 1) + [last_layer_size]
                layer_size_trunk  = [dim_x] + [t_width] * (t_depth - 1) + [last_layer_size]
            else:
                layer_size_branch = [m] + [b_width] * b_depth
                layer_size_trunk  = [dim_x] + [t_width] * t_depth
            
            self.logger.info(f"DeepONet Config: Branch({b_depth}x{b_width}), Trunk({t_depth}x{t_width}), P={last_layer_size if last_layer_size else 'Auto'}")
            
            net = dde.nn.DeepONet(layer_size_branch, layer_size_trunk, "tanh", "Glorot normal")
        elif self.model_type == 'FNO':
            X_train = self.data_dict['train_input'].astype(np.float32)
            y_train = self.data_dict['train_output'].astype(np.float32)
            X_test  = self.data_dict['test_input'].astype(np.float32)
            y_test  = self.data_dict['test_output'].astype(np.float32)

            from core.models_pt import FNOPT

            user_cfg = self.config.get('net_size', [])
            modes = user_cfg[0] if len(user_cfg) > 0 else 15
            width = user_cfg[1] if len(user_cfg) > 1 else 14
            depth = user_cfg[2] if len(user_cfg) > 2 else 3
            fc_hidden = user_cfg[3] if len(user_cfg) > 3 else 32

            in_channels = X_train.shape[-1]

            self.logger.info(f"FNO Config: modes={modes}, width={width}, depth={depth}, fc_hidden={fc_hidden}, in_channels={in_channels}")
            net = FNOPT(modes=modes, width=width, layers=depth, fc_hidden=fc_hidden, in_channels=in_channels)

        elif self.model_type == 'FNN':
            X_train = self.data_dict['train_input']
            X_test  = self.data_dict['test_input']
            y_train = self.data_dict['train_output']
            y_test  = self.data_dict['test_output']
            
            input_dim = X_train.shape[1]
            output_dim = 1
            net_size_cfg = self.config.get('net_size', [])

            # [depth, width] → expand to match FNNLayer(in, out, width, depth) which
            # has depth+2 Dense layers: fc0 + depth×hidden + fc_out.
            # DDE layer_sizes must be [in, width*(depth+1), out].
            if len(net_size_cfg) == 2:
                depth, width = int(net_size_cfg[0]), int(net_size_cfg[1])
                hidden_layers = [width] * (depth + 1)
            else:
                hidden_layers = list(net_size_cfg) if net_size_cfg else [20, 20, 20]

            layer_sizes = [input_dim] + hidden_layers + [output_dim]
            self.logger.info(f"FNN Structure: {layer_sizes}")
            net = dde.nn.FNN(layer_sizes, "tanh", "Glorot normal")
            
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")

        self.logger.info(f"Model Parameters: {count_parameters(net)}")

        dataset = Double(X_train, y_train, X_test, y_test)
        model = dde.Model(dataset, net)
        return model

    def train(self):
        """Execute training loop."""
        # Breakpoint resumption mechanism
        if self.exp_logger.is_completed():
            print(f"⏩ [Resume] The experiment has been completed. If the existing result file is detected, skip the training directly.")
            sys.exit(0)
            
        lr = self.config.get('learning_rate', 0.0001)
        epochs = self.config.get('num_epochs', 1000)

        num_samples = self.data_dict['train_output'].shape[0]
        current_bs = self.config.get('batch_size', 100)
        if num_samples < current_bs:
            self.logger.warning(f"⚠️ Batch size {current_bs} > total samples {num_samples}. Reducing to {num_samples}.")
            self.config['batch_size'] = num_samples

        batch_size = self.config.get('batch_size', 100)
        steps_per_epoch = max(1, int(np.ceil(num_samples / batch_size)))
        total_iterations = epochs * steps_per_epoch
        
        self.logger.info(f"Training Start. Epochs: {epochs}, BS: {batch_size}, Total Iter: {total_iterations}")
        
        opt_name  = self.config.get("optimizer", "adam").lower()
        sched     = self.config.get("lr_scheduler", "none").lower()
        sched_kw  = self.config.get("lr_scheduler_kwargs", {})
        decay = None
        if sched == "step":
            decay = ("step", sched_kw.get("step_size", sched_kw.get("decay_steps", 1000)), sched_kw.get("gamma", 0.9))
        elif sched == "exponential":
            decay = ("exponential", sched_kw.get("step_size", sched_kw.get("decay_steps", 1000)), sched_kw.get("gamma", 0.9))
        elif sched == "cosine":
            decay = ("cosine", sched_kw.get("T_max", total_iterations), sched_kw.get("alpha", 0.0))
        self.logger.info(f"Optimizer: {opt_name}, LR scheduler: {sched}")
        self.model.compile(
            opt_name,
            lr=lr,
            decay=decay,
            metrics=["l2 relative error"],
        )
        best_saver = BestModelCheckpoint(self) 
        losshistory, train_state = self.model.train(
            iterations=total_iterations, 
            batch_size=batch_size, 
            callbacks=[best_saver]
        )
        
        history = {
            'loss_train': [float(sum(x)) if isinstance(x, (list, tuple)) else float(x) for x in losshistory.loss_train],
            'loss_test': [float(sum(x)) if isinstance(x, (list, tuple)) else float(x) for x in losshistory.loss_test],
            'steps': [int(x) for x in losshistory.steps]
        }

        for i, (train_loss, test_loss, step) in enumerate(zip(history['loss_train'], history['loss_test'], history['steps'])):
             if i % max(1, len(history['steps']) // 100) == 0:
                 self.exp_logger.log_metric("Loss/train", train_loss, step)
                 self.exp_logger.log_metric("Loss/test", test_loss, step)
                 
        return history

    def evaluate(self, history=None):
        """Evaluate and Save."""
        self.logger.info("Evaluating model...")
        ckpt_path_final = self.exp_logger.get_ckpt_path(is_final=True).replace('.ckpt', '.pt')
        net = self.model.net
        state_dict_final = net.module.state_dict() if hasattr(net, 'module') else net.state_dict()
        torch.save(state_dict_final, ckpt_path_final)
        np.savez(ckpt_path_final.replace('.pt', '.npz'),
                 **{k: v.cpu().numpy() for k, v in state_dict_final.items()})
        self.logger.info(f"Saved final model to {ckpt_path_final}")

        best_ckpt_path = self.exp_logger.get_ckpt_path(is_final=False).replace('.ckpt', '.pt')
        if os.path.exists(best_ckpt_path):
            state_dict_best = torch.load(best_ckpt_path, map_location=torch.device('cpu'))
            if hasattr(net, 'module'):
                net.module.load_state_dict(state_dict_best)
            else:
                net.load_state_dict(state_dict_best)
            self.logger.info(f"Loaded BEST model for evaluation from {best_ckpt_path}")

        net.eval()
        X_test, y_true = self.model.data.test()
        y_pred = self.model.predict(X_test)

        l2_diff = np.linalg.norm(y_pred - y_true)
        l2_true = np.linalg.norm(y_true)
        rel_error = l2_diff / (l2_true + 1e-8)

        self.logger.info(f"⚡ Test Relative L2 Error: {rel_error:.6f} ({rel_error:.2%})")

        metrics = compute_metrics(y_true, y_pred)
        metrics['rel_l2'] = float(rel_error)

        self.logger.info(f"Final Metrics: {metrics}")

        self.exp_logger.save_metrics(metrics, history)

        self.exp_logger.close()
        return metrics